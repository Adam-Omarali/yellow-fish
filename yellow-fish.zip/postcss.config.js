module.exports = {
    plugins: {
      'postcss-plugin-name': {
        async: true,
      },
    },
  };
  
  
  
  
  
  
  